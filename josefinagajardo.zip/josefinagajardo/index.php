<?php include('header.php');?>
<!-- Navigation -->
<nav class="navbar fixed-top navbar-toggleable-md navbar-light" id="mainNav">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="#page-top">Portafolio</a>
        <div class="collapse navbar-collapse" id="navbarExample">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#about">Acerca de mí</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#services">Conocimiento</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#portfolio">Portafolio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contacto">Contacto</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <header class="masthead">
        <div class="header-content">
            <div class="header-content-inner">
                <h1 id="homeHeading">Josefina M. Gajardo</h1>
                <hr>
                <p>Estudiante de diseño, con afinidad en lo gráfico, textil y web.</p>

            </div>
        </div>
    </header>

    <section class="bg-primary" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 text-center">
                    <h2 class="section-heading text-white">Acerca de mí</h2>
                    <hr class="light">
                    <p class="text-faded">Veintiún años/Estudiante de diseño UC/Bilingüe</p>
                </div>
            </div>
        </div>
    </section>

    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Conocimientos</h2>
                    <hr>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-6 text-center">
                    <div class="service-box">
                        <img src= "img/iconos/illustrator.svg">
                        <h3>Illustrator</h3>
                        <p class="text-muted">Manejo básico.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center">
                    <div class="service-box">
                        <img src= "img/iconos/indesign.svg">
                        <h3>InDesign</h3>
                        <p class="text-muted">Manejo básico.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center">
                    <div class="service-box">
                        <img src= "img/iconos/camara.svg">
                        <h3>Fotografía</h3>
                        <p class="text-muted">Hobby con certificaciones de aprendizaje varias.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center">
                    <div class="service-box">
                        <img src= "img/iconos/coser.svg">
                        <h3>Máquinas de coser</h3>
                        <p class="text-muted">Cursado clases textiles.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center">
                    <div class="service-box">
                        <img src= "img/iconos/web.svg">
                        <h3>Web</h3>
                        <p class="text-muted">Yo hice esta página :)</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center">
                    <div class="service-box">
                        <img src= "img/iconos/libro.svg">
                        <h3>Editorial</h3>
                        <p class="text-muted">Elaboración editorial.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="no-padding" id="portfolio">
        <div class="container-fluid">
            <div class="row no-gutter popup-gallery">
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="melisai.php" target="_blank">
                        <img class="img-fluid" src="img/portafolio/melisai5.jpg">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-name">
                                    Melisai
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="acuarelas.php" target="_blank">
                        <img class="img-fluid" src="img/acuarela/acuarela6.jpg">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-name">
                                    Acuarela
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="xilo.php" target="_blank">
                        <img class="img-fluid" src="img/xilo/xilo3.jpg">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-name">
                                    Xilografía
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="stillus.php" target="_blank">
                    <img class="img-fluid" src="img/portafolio/stillus.jpg">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-name">
                                    Still Us
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="limonada.php" target="_blank">
                        <img class="img-fluid" src="img/portafolio/limonada.jpg">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-name">
                                    Limonada
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="tilecotil.php" target="_blank">
                        <img class="img-fluid" src="img/portafolio/tilecotil.jpg">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-name">
                                    Til Eco Til
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

<?php include('contacto.php');?>
</div>

    <?php include('footer.php');?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/creative.min.js"></script>

</body>

</html>
