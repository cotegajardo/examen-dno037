<?php include('header.php');?>
<!-- Navigation -->
<nav class="navbar fixed-top navbar-toggleable-md navbar-light" id="mainNav">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="http://josefinagajardo.cl/">Portafolio</a>
        <div class="collapse navbar-collapse" id="navbarExample">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#contexto">Contexto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#xilo">Xilografías</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<header class="masthead">
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Xilografía</h1>
            <hr>
            <h4>(2016)</h4>
        </div>
    </div>
</header>
<section id="contexto">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Contexto</h2>
                <hr>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>Los trabajos realizados se hicieron con matrices de mdf en su mayoría, terciado y tetra pack.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>Algunas de las técnicas utilizadas son taco perdido, grabado verde y el tallado normal.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                    <p>En algunos trabajos se debió utilizar una foto para tener la idea. En otros fue una adaptación. Además de la reinterpretación de obras como "Los Amantes" de René Magritte.</p>
                </div>
            </div>
          </div>
    </div>
</section>

<section class="no-padding" id="xilo">
    <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo1.jpg" alt="Retrato taco perdido a dos tintas">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo2.jpg" alt="Retrato sobre terciado">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo3.jpg" alt="Tallado de líneas; Granadas">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo4.jpg" alt="Reinterpretación de René Magritte">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo5.jpg" alt="Geometría sagrada uno">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo6.jpg" alt="Geometría sagrada dos">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo7.jpg" alt="Hojas de cerezo cayendo al agua">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo8.jpg" alt="Ramas de cerezo">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/xilo/xilo9.jpg" alt="Flores de cerezo">
          </div>
        </div>
      </div>
</section>

<?php include('footer.php');?>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/tether/tether.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="vendor/scrollreveal/scrollreveal.min.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- Custom scripts for this template -->
<script src="js/creative.min.js"></script>
