<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Portafolio de proyectos de diseño realizados por J. M. Gajardo">
    <meta name="author" content="Josefina M. Gajardo">
    <title>Josefina M. Gajardo</title>
    <link rel="icon" type="image/png" href="img/favicon.png">
    <!-- Search Engine -->
    <meta name="description" content="Portafolio de proyectos de diseño realizados por J. M. Gajardo">
    <meta name="image" content="…">
    <!-- Schema.org for Google -->
    <meta itemprop="name" content="Josefina M. Gajardo">
    <meta itemprop="description" content="Portafolio de proyectos de diseño realizados por J. M. Gajardo">
    <meta itemprop="image" content="img/search_engines.PNG">
    <!-- Twitter -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="Josefina M. Gajardo">
    <meta name="twitter:description" content="Portafolio de proyectos de diseño realizados por J. M. Gajardo">
    <!-- Open Graph general (Facebook, Pinterest & Google+) -->
    <meta name="og:title" content="Josefina M. Gajardo">
    <meta name="og:description" content="Portafolio de proyectos de diseño realizados por J. M. Gajardo">
    <meta name="og:image" content="img/search_engines.PNG">
    <meta name="og:url" content="http://josefinagajardo.cl/">
    <meta name="og:site_name" content="Josefina M. Gajardo">
    <meta name="og:type" content="website">


    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/creative.css" rel="stylesheet">

    <!-- Temporary navbar container fix -->
    <style>
    .navbar-toggler {
        z-index: 1;
    }

    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>

</head>

<body id="page-top">
