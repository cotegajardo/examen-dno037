<hr>
<footer>
  <div id="footer">
  <div class="row">
    <div class="col-lg-12 text-center">
          <a href="https://www.instagram.com/cotegajardo/" target="_blank">
          <img src="img/iconos/instagram.svg" width= 30>
          <a href="https://www.facebook.com/cotegajardo" target="_blank">
          <img src="img/iconos/facebook.svg" width= 30>
          <a href="https://www.behance.net/jmgajardo" target="_blank">
          <img src="img/iconos/behance.svg" width= 30>
      </div>    

  </div>
</div>
</footer>
