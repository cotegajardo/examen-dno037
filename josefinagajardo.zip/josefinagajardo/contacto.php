<section id="contacto">
  <div class="row">
    <div class="col-lg-12 text-center">
      <h2 class="section-heading">Contacto</h2>
      <hr>
      <br>
      <h6>Cualquier duda, escribe aquí! Demoraré poco en contestar.</h6>
    </div>
<br>
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<form name="contactform" method="post" action="enviar.php">
  <table width="300px">
  <tr>
  <td valign="top">
  <label for="first_name">Nombre*:</label>
  </td>
  <td valign="top">
  <input  type="text" name="first_name" maxlength="50" size="50">
  </td>
  </tr>
  <tr>
  <td valign="top">
  <label for="last_name">Apellido*:</label>
  </td>
  <td valign="top">
  <input  type="text" name="last_name" maxlength="50" size="50">
  </td>
  </tr>
  <tr>
  <td valign="top">
  <label for="email">Email*:</label>
  </td>
  <td valign="top">
  <input  type="text" name="email" maxlength="80" size="50">
  </td>
  </tr>
  <tr>
  <td valign="top">
  <label for="telephone">Teléfono:</label>
  </td>
  <td valign="top">
  <input  type="text" name="telephone" maxlength="30" size="50">
  </td>
  </tr>
  <tr>
  <td valign="top">
  <label for="comments">Mensaje*:</label>
  </td>
  <td valign="top">
  <textarea  name="comments" maxlength="3000" cols="53" rows="10"></textarea>
  </td>
  </tr>
  <tr>
  <td colspan="2" style="text-align:center">
  <button type="submit" class="btn btn-xl">Enviar mensaje</button>
  </td>
  </tr>
  </table>
</form>
</div>
</div><!--/col-sm-12-->
</div><!--/row-->
</section>
