<?php include('header.php');?>
<!-- Navigation -->
<nav class="navbar fixed-top navbar-toggleable-md navbar-light" id="mainNav">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="http://josefinagajardo.cl/">Portafolio</a>
        <div class="collapse navbar-collapse" id="navbarExample">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#contexto">Contexto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#melisai">Proyecto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#marcamelisai">Logo</a>
                </li>
            </ul>
        </div>
    </div>
</nav>


<header class="masthead">
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Melisai</h1>
            <hr>
            <h4>Rediseño de marca y productos a artesana de Talca.</h4>
            <h4>(2016)</h4>
        </div>
    </div>
</header>
<section id="contexto">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Contexto</h2>
                <hr>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>Fresia es una apicultora de Talca que produce miel y productos de belleza a partir de esta misma. Vende la miel por medio de su marca "Melisai de la colmena".</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>Bajo la misma marca, se le diseñó un logo hermano para la venta de los productos de belleza. Junto con el logo, se diseñaron los packaging de los productos, al igual que un exhibidor.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                    <p>Diseño de la tipografía principal de la marca, en conjunto con un manual de marca para la artesana. </p>
                </div>
            </div>
          </div>
    </div>
</section>

<section class="no-padding" id="melisai">
    <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/melisai/melisai1.jpg" alt="Shampoo, Bálsamo y jabón Melisai">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/melisai/melisai2.jpg" alt="Shampoo, exfoliante y crema de manos Melisai">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/melisai/melisai3.jpg" alt="Exhibidor con crema de manos, exfoliante y bálsamo de labios Melisai">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/melisai/melisai4.jpg" alt="Jabón y bálsamo de labios Melisai">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/melisai/melisai6.jpg" alt="Packaging pack de regalo shampoo, bálsamo y jabón Melisai">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/melisai/melisai7.jpg" alt="Exhibidor con todos los productos Melisai">
          </div>
        </div>
      </div>
</section>
<hr>
<section id="marcamelisai">
  <div class="row">
    <div class="col-lg-12 text-center">
      <img src="img/melisai/marca.jpg" width=500>
    </div>
  </div>
</section>
<?php include('footer.php');?>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/tether/tether.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="vendor/scrollreveal/scrollreveal.min.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- Custom scripts for this template -->
<script src="js/creative.min.js"></script>
