<?php include('header.php');?>
<!-- Navigation -->
<nav class="navbar fixed-top navbar-toggleable-md navbar-light" id="mainNav">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="http://josefinagajardo.cl/">Portafolio</a>
        <div class="collapse navbar-collapse" id="navbarExample">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#contexto">Contexto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#acuarelas">Acuarelas</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<header class="masthead">
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Acuarelas</h1>
            <hr>
            <h4>(2015)</h4>
        </div>
    </div>
</header>
<section id="contexto">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Contexto</h2>
                <hr>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>Acuarela sobre papel Fabriano.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>Hubo distintos tipos de consignas, como la reinterpretación de otro artista como Goya, realismo y naturaleza muerta.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                    <p>Texturas, detalles, sombras y luces</p>
                </div>
            </div>
          </div>
    </div>
</section>

<section class="no-padding" id="acuarelas">
    <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela2.jpg" alt="Reinterpretación obra Goya">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela1.jpg" alt="Estudio de texturas de animales">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela3.jpg" alt="Gato jaspeado durmiendo">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela4.jpg" alt="Mirada profunda de gato jaspeado">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela6.jpg" alt="Gatos gordos durmiendo">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela5.jpg" alt="Gato gris durmiendo con lengua afuera">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela7.jpg" alt="Naturaleza muerta berenjenas">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela8.jpg" alt="Naturaleza muerta peras">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= stillus-box>
              <img class="img-fluid" src="img/acuarela/acuarela9.jpg" alt="Naturaleza muerta casi guache">
          </div>
        </div>
      </div>
</section>

<?php include('footer.php');?>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/tether/tether.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="vendor/scrollreveal/scrollreveal.min.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- Custom scripts for this template -->
<script src="js/creative.min.js"></script>
