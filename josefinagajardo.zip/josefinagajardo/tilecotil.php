<?php include('header.php');?>
<!-- Navigation -->
<nav class="navbar fixed-top navbar-toggleable-md navbar-light" id="mainNav">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="container">
        <a class="navbar-brand" href="http://josefinagajardo.cl/">Portafolio</a>
        <div class="collapse navbar-collapse" id="navbarExample">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#contexto">Contexto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#til">Proyecto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#marcatil">Logo</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<header class="masthead">
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Til Eco Til</h1>
            <hr>
            <h4>Reutilización de desechos textiles.</h4>
            <h4>(2016)</h4>
        </div>
    </div>
</header>
<section id="contexto">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Contexto</h2>
                <hr>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 text-left">
                <div class="service-box">
                  <p>Brisa Zúñiga es una costurera de Til Til que imparte variados talleres dentro de la comuna y en sus alrededores. Uno de ellos es un taller de reciclaje.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                  <p>En este taller participan mujeres de entre 40 a 60 años aprox. que tienen la disposición de aprender manualidades nuevas. Por lo que Brisa les inculca la idea del reciclaje.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-justify">
                <div class="service-box">
                    <p>A partir de los desechos textiles que genera Brisa, se generaron líneas de accesorios con distintas técnicas de nudos. De esta manera, nace Til Eco Til, con la idea de que esta agrupación saque el máximo provecho a sus habilidades y puedan generar ingresos para ellas mismas.</p>
                </div>
            </div>
          </div>
    </div>
</section>

<section class="no-padding" id="til">
    <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
          <div class="col-lg-4 col-sm-6">
              <a class= til-box>
              <img class="img-fluid" src="img/tilecotil/til2.jpg" alt="Collar línea floral Til Eco Til">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= til-box>
              <img class="img-fluid" src="img/tilecotil/til1.jpg" alt="Cintillo línea floral Til Eco Til">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= til-box>
              <img class="img-fluid" src="img/tilecotil/til3.jpg" alt="Collar línea formal Til Eco Til">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= til-box>
              <img class="img-fluid" src="img/tilecotil/til4.jpg" alt="Cintillo línea marinera Til Eco Til">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= til-box>
              <img class="img-fluid" src="img/tilecotil/til5.jpg" alt="Pulsera línea marinera Til Eco Til">
          </div>
          <div class="col-lg-4 col-sm-6">
              <a class= til-box>
              <img class="img-fluid" src="img/tilecotil/til6.jpg" alt="Collar línea marinera Til Eco Til">
          </div>
        </div>
      </div>
</section>
<hr>
<section id="marcatil">
  <div class="row">
    <div class="col-lg-12 text-center">
      <img src="img/tilecotil/marca.svg" height= 400>
    </div>
  </div>
</section>
<?php include('footer.php');?>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/tether/tether.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="vendor/scrollreveal/scrollreveal.min.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- Custom scripts for this template -->
<script src="js/creative.min.js"></script>
